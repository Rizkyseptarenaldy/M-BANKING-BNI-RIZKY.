package com.example.mobilebanking_rizky_septa_renaldy_411222068;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uas_m_banking_rizkyseptarenaldy_411222068.R;

public class MyCard extends AppCompatActivity {

    Button home, statistik;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycard);

        // Hubungkan tombol Home dari layout
        home = findViewById(R.id.mycardBtn);
        statistik = findViewById(R.id.logoutBtn);

        // Logika tombol Home
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyCard.this, MainActivity.class);
                startActivity(intent);
                finish(); // Tutup MyCard agar tidak menumpuk di back stack
            }
        });
        statistik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyCard.this, Statistik.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
