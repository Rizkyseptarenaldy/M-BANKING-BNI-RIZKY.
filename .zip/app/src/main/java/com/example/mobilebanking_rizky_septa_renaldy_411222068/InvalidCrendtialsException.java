package com.example.mobilebanking_rizky_septa_renaldy_411222068;

public class InvalidCredentialsException extends Exception {

    public InvalidCredentialsException(String message) {
        super(message);
    }
}